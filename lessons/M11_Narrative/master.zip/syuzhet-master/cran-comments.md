## Test environments
* local OS X install, R 4.0.3
* ubuntu 14.04 (on travis-ci), R 3.4.2
* win-builder (devel and release)

## R CMD check results
0 errors | 0 warnings | 1 note
R CMD check succeeded